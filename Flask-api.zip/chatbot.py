import requests
from dotenv import load_dotenv
import os

load_dotenv()

api_key=os.getenv("API_KEY")

def get_answer(question):
    headers = {
        "Authorization": f"Bearer {api_key}",
        "Accept": "application/json"
    }

    data = {
        "messages": [ 
            {
                "role": "user", 
                "content": question
            }
        ],
        "model": "llama-3.3-70b-versatile"
    }

    res=requests.post("https://api.groq.com/openai/v1/chat/completions",headers=headers,json=data)

    print("status code: ",res.status_code)
    # print("response: ",res.json())

    answer=res.json()['choices'][0]['message']['content']
    return answer

print(get_answer("What is computer?"))
    # import json
    # with open("response.json", "w") as f:
    #     json.dump(res.json(), f, indent=2)

"""
curl -X POST "https://api.groq.com/openai/v1/chat/completions" \
     -H "Authorization: Bearer $GROQ_API_KEY" \
     -H "Content-Type: application/json" \
     -d '{"messages": [{"role": "user", "content": "Explain the importance of fast language models"}], "model": "llama-3.3-70b-versatile"}'
"""